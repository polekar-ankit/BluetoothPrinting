package com.gipl.posbilling.utility.print;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.SystemClock;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.gipl.posbilling.exception.CustomException;
import com.gipl.posbilling.ui.modles.BTDevice;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.Executors;

/**
 * Created by Ankit on 03-Sep-19.
 */
public class PrintReceipt {
    private BluetoothSocket bluetoothSocket;

    public MutableLiveData<Exception> getPrintException() {
        return printException;
    }

    private MutableLiveData<Exception> printException = new MutableLiveData<>();
    private UUID applicationUUID = UUID
            .fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice bluetoothDevice;
    private String sReceipt = "";

    public boolean hasPendingPrint() {
        return !sReceipt.isEmpty();
    }

    private MutableLiveData<BluetoothSocket> bluetoothSocketMutableLiveData = new MutableLiveData<>();

    public boolean clearOldReceipt() {
        sReceipt = "";
        return true;
    }

    public PrintReceipt() {
        this.bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    public boolean isBluetoothDeviceConnected() {
        return bluetoothSocket != null;
    }

    public BluetoothAdapter getBluetoothAdapter() {
        return bluetoothAdapter;
    }

    public void printReceipt() {
        Executors.newSingleThreadExecutor().submit(() -> {
            try {
                OutputStream outputStream = bluetoothSocket.getOutputStream();
                if (outputStream != null) {
                    if (WriteFont(true, outputStream)) {
                        outputStream.flush();
                        outputStream.write(sReceipt.getBytes(), 0, sReceipt.length());
                        outputStream.write("\n\n".getBytes());
                        outputStream.flush();
                        SystemClock.sleep(1000);
                        printException.postValue(null);
                    }
                } else {
                    printException.postValue(new CustomException("Unable to print"));
                }
            } catch (IOException e) {
                printException.postValue(e);
            }
        });
    }

    private boolean WriteFont(boolean isBold, OutputStream outputStream) throws IOException {
        byte[] command = PrintUtil.getFontStyle(isBold);
        outputStream.write(command, 0, command.length);
        return true;
    }

    public void connectToSocket(BTDevice btDevice) {
        this.bluetoothDevice = bluetoothAdapter.getRemoteDevice(btDevice.getMacAddress());

        Executors.newSingleThreadExecutor().submit(() -> {
            try {
                BluetoothSocket bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(applicationUUID);
                bluetoothAdapter.cancelDiscovery();
                bluetoothSocket.connect();
                bluetoothSocketMutableLiveData.postValue(bluetoothSocket);
            } catch (IOException e) {
                bluetoothSocketMutableLiveData.postValue(null);
                printException.postValue(e);
            }
        });

    }

    public void processSocket(BluetoothSocket bluetoothSocket) {
        if (bluetoothSocket != null) {
            this.bluetoothSocket = bluetoothSocket;
            if (!sReceipt.isEmpty())
                printReceipt();
        }
    }

    public MutableLiveData<BluetoothSocket> getBluetoothSocketMutableLiveData() {
        return bluetoothSocketMutableLiveData;
    }

    public void setReceipt(String receipt) {
        if (clearOldReceipt())
            this.sReceipt = receipt;
    }


    public void closeSocket() {
        try {
            if (bluetoothSocket != null)
                bluetoothSocket.close();
        } catch (IOException ex) {
        }
    }
}
