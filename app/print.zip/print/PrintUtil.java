package com.gipl.posbilling.utility.print;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 * Created by Ankit on 03-Sep-19.
 */
public class PrintUtil {
    public static int MESSAGE_LENGTH_SCRIPT_80 = 64 ;//=+16=-8;
//    public static int MESSAGE_LENGTH_SCRIPT_80 = 42 ;//=+10=-5;

    public static byte[] getFontStyle(boolean isBold) {

        byte FontStyleVal = 0;
        FontStyleVal = (byte) (FontStyleVal & 252);
        if (isBold) {
                FontStyleVal = (byte) (FontStyleVal | 2);
                FontStyleVal = ((byte) ((FontStyleVal | 8)));
            } else {
                FontStyleVal = ((byte) ((FontStyleVal | 2)));
                FontStyleVal = ((byte) ((FontStyleVal & 247)));
            }

        return new byte[]{0x1B, 0x21,
                FontStyleVal};

    }

    public static String getHorizontalLine(){
        StringBuilder lineBuilder = new StringBuilder();
        for (int i=0;i<MESSAGE_LENGTH_SCRIPT_80;i++){
            lineBuilder.append("-");
        }
        return lineBuilder.toString();
    }

    static String getHeader(String[] headerList){
        StringBuilder stringBuilder = new StringBuilder();
        for (String header :
                headerList) {
            stringBuilder.append(getStringWithWhiteSpaces(header));
        }
        return stringBuilder.toString();
    }

    private static String getStringWithWhiteSpaces(String strVal) {
        int startWhite = getStartBlankSpace(strVal.length());
        int endWhiteSpace = MESSAGE_LENGTH_SCRIPT_80 - (startWhite + strVal.length());

        return (startWhite>0?String.format("%1$" + startWhite + "s", ""):"") + strVal + (endWhiteSpace>0?String.format("%1$" + endWhiteSpace + "s", ""):"");
    }

    private static int getStartBlankSpace(int strlen) {
        return ((MESSAGE_LENGTH_SCRIPT_80 / 2) - (strlen / 2)) - 1;
    }
}
