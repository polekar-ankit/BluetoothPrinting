package com.gipl.posbilling.utility.print;

import com.gipl.posbilling.ui.salesscreen.adapters.VSales;
import com.gipl.posbilling.utility.AppUtility;

import java.util.ArrayList;

import static com.gipl.posbilling.utility.AppUtility.getEmptySpaces;
import static com.gipl.posbilling.utility.print.PrintUtil.MESSAGE_LENGTH_SCRIPT_80;
import static com.gipl.posbilling.utility.print.PrintUtil.getHorizontalLine;

/**
 * Created by Ankit on 03-Sep-19.
 */
public class ReceiptGenerator {
    public static String[] HEADERS = new String[]{"Gadre Marine Pvt Ltd",
            "Plot FP-1, MIDC, Mirjole Block, Ratnagiri", "Maharashtra 415639", "GSTIN No : 1293371981732"};
    String rs;

    public ReceiptGenerator(String rs) {
        this.rs = rs;
    }


    public String getReceiptString(String billNo,
                                   String date,
                                   ArrayList<VSales> vSalesArrayList,
                                   double subTotal,
                                   double cgstTotal,
                                   double sgstTotal,
                                   double grandTotal) {


        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(PrintUtil.getHeader(HEADERS));

        String bill = "Bill No." + billNo;
        stringBuilder.append(bill);
        stringBuilder.append(String.format("%1$" + (MESSAGE_LENGTH_SCRIPT_80 - bill.length()) + "s", "Date :" + date));
        stringBuilder.append(getHorizontalLine());

        stringBuilder.append(tableRowWhiteSPace("Product Name", "Quantity", "Amount"));
        stringBuilder.append(getHorizontalLine());
        for (VSales sales :
                vSalesArrayList) {
            String porName = sales.getProduct().getProductName();
            String qtn = String.valueOf(sales.getQuantityValue());
            String amt = String.valueOf(sales.getAmountValue());
            stringBuilder.append(tableRowWhiteSPace(porName, qtn, amt));
        }
        stringBuilder.append(getHorizontalLine());

        stringBuilder.append(tableTotalsSPace("", "Total :", getEmptySpaces(("" + subTotal).length() - ("" + subTotal).length()) + subTotal));
        stringBuilder.append(tableTotalsSPace("", "CGST :", getEmptySpaces(("" + subTotal).length() - ("" + cgstTotal).length()) + cgstTotal));
        stringBuilder.append(tableTotalsSPace("", "SGST :", getEmptySpaces(("" + subTotal).length() - ("" + sgstTotal).length()) + sgstTotal));

        stringBuilder.append(getHorizontalLine());
        stringBuilder.append(tableTotalsSPace("", "Grand total :", rs + grandTotal));


        return stringBuilder.toString();
    }


    private String tableRowWhiteSPace(String cell1, String cell2, String cell3) {
        StringBuilder stringBuilder = new StringBuilder();

        int numberOfColumn = 3;
        int cellCharForEach = (MESSAGE_LENGTH_SCRIPT_80 / numberOfColumn);
        int cellCharForFirst = cellCharForEach + (MESSAGE_LENGTH_SCRIPT_80 / 4);
        int cellCharForOher2 = cellCharForEach - (MESSAGE_LENGTH_SCRIPT_80 / 8);

        int firstCellEmpty = 0, secondCellEmpty = 0, thirdCellEmpty;

        if (cell1.length() <= cellCharForFirst) {

            int val = cellCharForFirst - cell1.length();
            firstCellEmpty = (val <= 0) ? 0 : val;

            secondCellEmpty = (cellCharForOher2 - cell2.length());
            secondCellEmpty = secondCellEmpty <= 0 ? 0 : secondCellEmpty;

//            thirdCellEmpty = ((cellCharForOher2 - cell3.length()) + 1);
            thirdCellEmpty = ((cellCharForOher2 - cell3.length()));
            thirdCellEmpty = thirdCellEmpty <= 0 ? 0 : thirdCellEmpty;


            stringBuilder.append(String.format("%s%s%s%s%s%s",
                    cell1,
                    firstCellEmpty != 0 ? String.format("%1$" + firstCellEmpty + "s", "") : "",
                    cell2,
                    secondCellEmpty != 0 ? String.format("%1$" + secondCellEmpty + "s", "") : "",
                    cell3,
                    thirdCellEmpty != 0 ? String.format("%1$" + thirdCellEmpty + "s", "") : ""));

        } else {
            String cellFSub = cell1.substring(0, cellCharForFirst - 5);
            String cellSSub = cell1.substring(cellCharForFirst - 5);

            int val = cellCharForFirst - cellFSub.length();
            firstCellEmpty = (val <= 0) ? 0 : val;

            secondCellEmpty = (cellCharForOher2 - cell2.length());
            secondCellEmpty = secondCellEmpty <= 0 ? 0 : secondCellEmpty;

            thirdCellEmpty = ((cellCharForOher2 - cell3.length()) + 1);
            thirdCellEmpty = thirdCellEmpty <= 0 ? 0 : thirdCellEmpty;

            stringBuilder.append(String.format("%s%s%s%s%s%s",
                    cellFSub,
                    String.format("%1$" + firstCellEmpty + "s", ""),
                    cell2,
                    String.format("%1$" + secondCellEmpty + "s", ""),
                    cell3,
                    String.format("%1$" + thirdCellEmpty + "s", "")));

            stringBuilder.append(String.format("%s%s%s%s",
                    cellSSub,
                    String.format("%1$" + (cellCharForFirst - cellSSub.length()) + "s", ""),
                    String.format("%1$" + (cellCharForOher2) + "s", ""),
                    String.format("%1$" + ((cellCharForOher2) + 1) + "s", "")));
        }

        if (stringBuilder.toString().length() < MESSAGE_LENGTH_SCRIPT_80) {
            stringBuilder.append(AppUtility.getEmptySpaces(MESSAGE_LENGTH_SCRIPT_80 - stringBuilder.toString().length()));
        }

        return stringBuilder.toString();
    }

    private String tableTotalsSPace(String cell1, String cell2, String cell3) {
        int numberOfColumn = 3;
        int cellCharForEach = (MESSAGE_LENGTH_SCRIPT_80 / numberOfColumn);
//        int cellCharForFirst = cellCharForEach + 13;
        int cellCharForFirst = cellCharForEach + (MESSAGE_LENGTH_SCRIPT_80 / 5);
//        int cellCharForOher2 = cellCharForEach - 5;
        int cellCharForOher2 = cellCharForEach - (MESSAGE_LENGTH_SCRIPT_80 / 13);
//        int cellForoter3 = cellCharForEach - 8;
        int cellForoter3 = cellCharForEach - (MESSAGE_LENGTH_SCRIPT_80 / 8);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("%s%s%s%s%s%s",
                cell1,
                String.format("%1$" + (cellCharForFirst - cell1.length()) + "s", ""),
                cell2,
                String.format("%1$" + (cellCharForOher2 - cell2.length()) + "s", ""),
                cell3,
//                String.format("%1$" + ((cellForoter3 - cell3.length()) + 1) + "s", ""));
                String.format("%1$" + ((cellForoter3 - cell3.length())) + "s", "")));

        if (stringBuilder.toString().length() < MESSAGE_LENGTH_SCRIPT_80) {
            stringBuilder.append(AppUtility.getEmptySpaces(MESSAGE_LENGTH_SCRIPT_80 - stringBuilder.toString().length()));
        }

        return stringBuilder.toString();
    }


}
